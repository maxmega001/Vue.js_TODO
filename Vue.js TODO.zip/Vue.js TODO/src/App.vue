<template>
  <div id="app">
    <myForm @SendTasks="tasks = $event" nameBtn="Add"></myForm>
    <hr>
    <TasksPlace :listTasks="tasks"></TasksPlace>
  </div>
</template>

<script>
import TasksPlace from './components/TasksPlace'
import myForm from './components/myForm'
export default {
  name: 'App',
  components: {
    myForm,
    TasksPlace
  },
  data(){
    return{
      tasks:[]
    }
  }
}
</script>

<style>
#app {
  height: auto;
  font-size: 25px;
}
</style>
