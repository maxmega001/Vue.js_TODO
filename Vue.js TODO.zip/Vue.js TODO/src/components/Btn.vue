<template>
    <div id="btn">
        <button @click="action">{{name}}</button>
    </div>
</template>

<script>
    export default {
        name: "Btn",
        props: {
            name: String,
        },
        data(){
            return {}
        },
        methods:{
            action(){
                if(name=="Редактировать"){

                }
                if(name=="Удалить"){
                    this.$emit('act','del');
                }
            }
        }
    }
</script>

<style scoped>

</style>
