<template>
  <div class="btnlist">
    <menuButton name="Family"></menuButton>
    <menuButton name="Work"></menuButton>
    <menuButton name="Sport"></menuButton>
  </div>
</template>

<script>
import menuButton from './menuButton'

export default {
  name: 'ButtonList',
  components:{
      menuButton
  },
  data () {
    return {
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
    .btnlist{
        display: flex;
        justify-content: space-around;
    }
</style>
