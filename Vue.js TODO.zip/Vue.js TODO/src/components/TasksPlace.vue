<template>
    <div>
        <div v-for="(el) in listTasks" class="taskitemplace" :class="{green:el.done, red:el.date<new Date()}" v-bind:key="el.id">
            <div v-if="el.id==num">
                <form action="" @submit.prevent="changeTask">
                    <p><input type="text" :placeholder="el.task" v-model="form.task"></p>
                    <p><input type="date"  v-model="form.date"></p>
                    <Btn name="Сохранить"></Btn>
                </form>
            </div>
            <div v-else>
                <p>{{el.task}}</p>
                <p class="info">{{new Date(el.date).toLocaleDateString()}}</p>
            </div>
            <label><input type="checkbox" v-model="el.done">Сделано</label>
            <br>
            <Btn class="btn" name="Редактировать" v-on:click.native="num = el.id"></Btn>
            <Btn class="btn" name="Удалить"  v-on:click.native="removeTask(key), num = -1"></Btn>
        </div>
    </div>
</template>

<script>
import Btn from "./Btn.vue"
import myForm from "./myForm.vue"
    export default {
        name: "TasksPlace",
        components:{
            Btn,
            myForm
        },
        props: {
            listTasks: {
                type:Array,
                default: {id:-1,task:'',date: new Date()}
            }
        },
        data(){
            return {
                form:{
                    task:'',
                    date: new Date(),
                },
                num: -1,
                che: false,
            }
        },
        methods:{
            removeTask(e){
                this.listTasks.splice(e, 1);
            },
            changeTask(e){
                console.log(this.listTasks[this.num].done);
                if (this.form.task!=''){
                    this.listTasks[this.num].task = this.form.task;
                    this.listTasks[this.num].date = new Date(this.form.date.substr(5, 2) + '/' + this.form.date.substr(8, 2) + '/' + this.form.date.substr(0, 4));
                    // this.$emit('SendTasks', this.tasks);
                    this.num = -1
                }else{
                    console.log('Empty field')
                }
            }
        }
    }

</script>

<style scoped>
    .taskitemplace{
        background-color: turquoise;
        border: 3px solid lightskyblue;
    }
    .green{
        background-color: limegreen!important;
    }
    .red{
        background-color: red;
    }
    .btn{
        display: inline;
    }
    .active{
        display: block;
    }
    .disable{
        display: none;
    }
</style>
