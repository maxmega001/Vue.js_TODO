<template>
    <div id="btn">
        <form class="f" action="" @submit.prevent="AddTask">
            <input type="text" v-model="form.task">
            <input type="date" v-model="form.date">
            <Btn :name="nameBtn"></Btn>    
        </form>
    </div>
</template>

<script>
import Btn from "./Btn.vue"
    export default {
        name: "myForm",
        components:{
            Btn
        },
        props: {
            nameBtn: String,
        },
        data(){
            return {
                form:{
                    task:'',
                    date: new Date(),
                },
                tasks:[],
            }
        },
        methods:{
            AddTask(){
                console.log(this.form.task);
                if (this.form.task!=''){
                    this.tasks.push({
                        id: this.tasks.length,
                        task: this.form.task,
                        date: new Date(this.form.date.substr(5, 2) + '/' + this.form.date.substr(8, 2) + '/' + this.form.date.substr(0, 4)),
                        done: false,
                    });
                    this.$emit('SendTasks', this.tasks);
                }else{
                    console.log('Empty field')
                }
            }
            
        }
    }

</script>

<style scoped>

</style>
