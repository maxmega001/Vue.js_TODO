<template>
  <div class="btn">
      <button>{{name}}</button>
  </div>
</template>

<script>
export default {
  name: 'Btn',
  props: {
      name: String
  },
  data () {
    return {
        pages: ['dcxvd'],
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
    .btn > button{
        height: 40px;
        width: 100px;
        border: none;
        border-radius: 25%;
        background-color: #de1e4d;
        color: white;
        font-family: sans-serif;
        font-size: 20px;
    }
</style>
